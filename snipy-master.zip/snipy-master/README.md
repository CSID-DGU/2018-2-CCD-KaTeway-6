# snipy
Sniffing module in Python
